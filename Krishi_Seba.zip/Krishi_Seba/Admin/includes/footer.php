               
                <footer class="footer">
                    <div style="text-align:center;"> All rights reserved | Copyright © 2020 | Designed & Developed by : AK Srabon</div>
                </footer> 